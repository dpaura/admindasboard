<?php
 $connect = mysqli_connect("localhost", "root", "", "population");
 $query ="SELECT * FROM abau ORDER BY Fname DESC LIMIT 3000";
 $result = mysqli_query($connect, $query);
 ?>
 <!DOCTYPE html>
 <html>
      <head>
           <title>CPG</title>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />

                  <!--modal script-->
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


      </head>
      <body>
           <br /><br />
           <div class="container">
                <h3 align="center">ABAU DATA</h3>
                <br />
                <div class="table-responsive">
                     <table id="employee_data" class="table table-striped table-bordered">
                          <thead>
                               <tr>
                                    <td>FirstName</td>
                                      <td>ID</td>
                                    <td>LastName</td>
                                    <td>Gender</td>
                                    <td>District</td>
                                    <td>Ward</td>
                                      <td>View</td>
                               </tr>
                          </thead>
                          <?php
                          while($row = mysqli_fetch_array($result))
                          {
                               echo '
                               <tr>
                                    <td>'.$row["Fname"].'</td>
                                      <td>'.$row["_id"].'</td>
                                    <td>'.$row["Lname"].'</td>
                                    <td>'.$row["Sex"].'</td>
                                    <td>'.$row["District"].'</td>
                                    <td>'.$row["Ward"].'</td>
                                <td><button type="button" name="view" class="btn btn-info view" id="'.$row["_id"].'" >View</button></td>
                               </tr>
                               ';
                          }
                          ?>
                     </table>
                </div>
           </div>
      </body>
 </html>
<!--modal-->

<div id="post_modal" class="modal fade">
      <div class= "modal-dialog">
        <div class= "modal-content">
          <!--modal header-->
          <div class= "modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Record Details</h4>
          </div>
          <!--modal body-->
          <div class="modal-body" id="post_detail">

          </div>
          <!--modal footer-->
          <div class="modal-footer">
           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
</div>


 <script>

 $(document).ready(function(){
      $('#employee_data').DataTable();
 });
 </script>

 <script>
 $(document).ready(function(){

  function fetch_post_data(_id)
  {
   $.ajax({
    url:"fetch.php",
    method:"POST",
    data:{_id:_id},
    success:function(data)
    {
     $('#post_modal').modal('show');
     $('#post_detail').html(data);
    }
   });
  }

  $(document).on('click', '.view', function(){
   var _id = $(this).attr("id");
   fetch_post_data(_id);
  });

  $(document).on('click', '.previous', function(){
   var _id = $(this).attr("id");
   fetch_post_data(_id);
  });

  $(document).on('click', '.next', function(){
   var post_id = $(this).attr("id");
   fetch_post_data(post_id);
  });

 });
 </script>
