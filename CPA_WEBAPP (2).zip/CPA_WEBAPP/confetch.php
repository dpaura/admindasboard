<?php
//fetch.php
if(isset($_POST["_id"]))
{
 $connect = mysqli_connect("localhost", "root", "", "population");
 $output = '';
 $query = "SELECT * FROM abau WHERE _id = '".$_POST["_id"]."'";
 $result = mysqli_query($connect, $query);
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
  <p>First Name : <span>'.$row["Fname"].'</span></p>
  <p>Last Name: <span>'.$row["Lname"].' </span></p>
  <p>District: <span>'.$row["District"].' </span></p>
  <p>Ward : <span>'.$row["Ward"].' </span></p>
  <p>LLG : <span>'.$row["LLG"].'</span></p>
  <p>DOB: <span>'.$row["DOB"].' </span></p>
  <p>Gender: <span>'.$row["Sex"].' </span></p>
  <p>Occupation : <span>'.$row["Occupation"].' </span></p>

  ';
  $query_1 = "SELECT * FROM abau WHERE _id < '".$_POST['_id']."' ORDER BY _id DESC LIMIT 1";
  $result_1 = mysqli_query($connect, $query_1);
  $data_1 = mysqli_fetch_assoc($result_1);

  $query_2 = "SELECT _id FROM abau WHERE _id > '".$_POST['_id']."' ORDER BY _id ASC LIMIT 1";
  $result_2 = mysqli_query($connect, $query_2);
  $data_2 = mysqli_fetch_assoc($result_2);
  $if_previous_disable = '';
  $if_next_disable = '';
  if($data_1["_id"] == "")
  {
   $if_previous_disable = 'disabled';
  }
  if($data_2["_id"] == "")
  {
   $if_next_disable = 'disabled';
  }
  $output .= '
  <br /><br />
  <div align="center">
   <button type="button" name="previous" class="btn btn-warning btn-sm previous" id="'.$data_1["_id"].'" '.$if_previous_disable.'>Previous</button>
   <button type="button" name="next" class="btn btn-warning btn-sm next" id="'.$data_2["_id"].'" '.$if_next_disable.'>Next</button>
  </div>
  <br /><br />
  ';
 }
 echo $output;
}

?>
