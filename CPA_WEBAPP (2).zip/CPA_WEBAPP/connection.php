<?php
mysql_connect('localhost','root','population');
mysql_select_db('population');






echo "<table>";

// table header
echo "<tr><th>id</th><th>Name</th><th>Lastname</th></tr>";

// output data of each row
while($row = $result->fetch_assoc()) {

    echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["lastName"]."</td></tr>";
}

// table footer

echo "</table>";


?>
